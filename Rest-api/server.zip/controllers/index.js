const authController = require('./auth');
const fruitController = require('./fruitController');
const recipeController = require('./recipeController');

module.exports = {
    authController,
    fruitController,
    recipeController,
}